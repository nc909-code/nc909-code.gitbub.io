// ─── HERO IMAGE LOAD ──────────────────────────────────────────
const heroImg = document.querySelector('.hero__image');
if (heroImg) {
  if (heroImg.complete) {
    heroImg.classList.add('loaded');
  } else {
    heroImg.addEventListener('load', () => heroImg.classList.add('loaded'));
  }
}

// ─── NAV SCROLL EFFECT ────────────────────────────────────────
const nav = document.getElementById('nav');
window.addEventListener('scroll', () => {
  nav.classList.toggle('scrolled', window.scrollY > 40);
});

// ─── SCROLL REVEAL ───────────────────────────────────────────
const revealElements = document.querySelectorAll('.reveal');

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, {
  threshold: 0.12,
  rootMargin: '0px 0px -40px 0px'
});

revealElements.forEach(el => revealObserver.observe(el));

// ─── SMOOTH ACTIVE NAV LINKS ──────────────────────────────────
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav__links a');

const sectionObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      navLinks.forEach(link => {
        link.style.color = '';
        if (link.getAttribute('href') === `#${entry.target.id}`) {
          link.style.color = 'var(--teal)';
        }
      });
    }
  });
}, { threshold: 0.4 });

sections.forEach(section => sectionObserver.observe(section));

// ─── MOBILE NAV TOGGLE ────────────────────────────────────────
const navToggle = document.getElementById('navToggle');
const navLinksEl = document.querySelector('.nav__links');

if (navToggle) {
  navToggle.addEventListener('click', () => {
    const isOpen = navLinksEl.style.display === 'flex';
    navLinksEl.style.display = isOpen ? 'none' : 'flex';
    navLinksEl.style.flexDirection = 'column';
    navLinksEl.style.position = 'absolute';
    navLinksEl.style.top = '60px';
    navLinksEl.style.right = '24px';
    navLinksEl.style.background = 'white';
    navLinksEl.style.padding = '20px 28px';
    navLinksEl.style.borderRadius = '12px';
    navLinksEl.style.boxShadow = '0 8px 32px rgba(0,0,0,0.1)';
    navLinksEl.style.gap = '16px';
  });

  // Close on link click
  navLinksEl.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      navLinksEl.style.display = 'none';
    });
  });
}
